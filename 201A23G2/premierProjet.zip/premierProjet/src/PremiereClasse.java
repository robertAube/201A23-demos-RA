public class PremiereClasse {
    public static void main(String[] args) {
        System.out.println("Bonjour le monde1!"); //afficher la chaîne de caractères "Bonjour le monde"
        System.out.println("Bonjour le monde2!"); //afficher la chaîne de caractères "Bonjour le monde"
        System.out.println("Bonjour le monde3!"); //afficher la chaîne de caractères "Bonjour le monde"
        System.out.println("Bonjour le monde4!"); //afficher la chaîne de caractères "Bonjour le monde"
        System.out.println("Bonjour le monde5!"); //afficher la chaîne de caractères "Bonjour le monde"
    }
}

